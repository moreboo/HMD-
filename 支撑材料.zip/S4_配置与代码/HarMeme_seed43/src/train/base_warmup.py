"""Validation-selected base pretraining; transfer only the two base modules."""
from pathlib import Path
import json
import numpy as np
import torch
from torch.utils.data import DataLoader

from src.data.epc_data import EvidenceDataset, EvidenceCollator, sha256
from src.models.epc_ecn import EPCConfig, EPCECN
from src.train.checkpointing import save_checkpoint, capture_rng, restore_rng


def validate_warmup(settings):
    if not settings or not settings.get('enabled', False):
        return
    for k in ['epochs', 'patience', 'batch_size']:
        if isinstance(settings[k], bool) or not isinstance(settings[k], int) or settings[k] < 1:
            raise ValueError('Invalid warmup '+k)
    for k in ['learning_rate', 'gradient_clip']:
        if not np.isfinite(settings[k]) or settings[k] <= 0:
            raise ValueError('Invalid warmup '+k)


def warmup_base(model, bundle, settings, seed, device, destination, joint_generator):
    from src.train.train_epc_ecn import seed_everything, evaluate, save_validation_rows
    validate_warmup(settings)
    if not model.config.use_base:
        raise ValueError('Base warmup requires a base branch')
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=False)
    # A separate model avoids modifying RoBERTa/fusion state or joint data ordering.
    joint_rng = capture_rng(joint_generator)
    try:
        seed_everything(seed)
        config = model.config.to_dict()
        config['use_explanation'] = False
        config['base_gradient_mode'] = 'joint'
        base = EPCECN(EPCConfig(**config)).to(device)
        datasets = {s: EvidenceDataset(bundle, s) for s in ['train', 'val']}
        generator = torch.Generator().manual_seed(seed)
        loader = DataLoader(datasets['train'], batch_size=settings['batch_size'], shuffle=True,
                            generator=generator, collate_fn=EvidenceCollator())
        validation = DataLoader(datasets['val'], batch_size=settings['batch_size'],
                                collate_fn=EvidenceCollator())
        optimizer = torch.optim.AdamW(base.parameters(), lr=settings['learning_rate'],
                                      weight_decay=settings.get('weight_decay', .01))
        best, best_epoch, history = -float('inf'), 0, []
        for epoch in range(1, settings['epochs']+1):
            base.train(); total = 0.
            for batch in loader:
                optimizer.zero_grad(set_to_none=True)
                logits = base(batch['image'].to(device), batch['text'].to(device))['logits']
                loss = torch.nn.functional.cross_entropy(logits, batch['labels'].to(device))
                if not torch.isfinite(loss):
                    raise FloatingPointError('Nonfinite base warmup loss')
                loss.backward()
                torch.nn.utils.clip_grad_norm_(base.parameters(), settings['gradient_clip'], error_if_nonfinite=True)
                optimizer.step(); total += loss.item()*len(batch['labels'])
            score, rows = evaluate(base, validation, device)
            if score['auroc'] is None or not np.isfinite(score['auroc']):
                raise ValueError('Warmup validation AUROC is undefined')
            p = np.array([r['probability'] for r in rows])
            record = dict(epoch=epoch, train_loss=total/len(datasets['train']), validation=score,
                          positive_predictions=int((p>=.5).sum()), probability_min=float(p.min()),
                          probability_max=float(p.max()))
            history.append(record)
            with (destination/'history.jsonl').open('a', encoding='utf-8') as f:
                f.write(json.dumps(record)+'\n')
            checkpoint = dict(model_state_dict=base.state_dict(), epoch=epoch, validation=score,
                              seed=seed, cache_sha256=bundle['metadata']['bundle_sha256'], settings=settings)
            if score['auroc'] > best:
                best, best_epoch = score['auroc'], epoch
                save_checkpoint(checkpoint, destination/'best.pt')
                save_validation_rows(destination/'validation_best.csv', rows, epoch)
            save_checkpoint(checkpoint, destination/'last.pt')
            print('Base warmup: '+json.dumps(record), flush=True)
            if epoch-best_epoch >= settings['patience']:
                break
        selected = torch.load(destination/'best.pt', map_location='cpu', weights_only=True)
        expected = {k for k in model.state_dict() if k.startswith(('base_encoder.','base_classifier.'))}
        if set(selected['model_state_dict']) != expected:
            raise ValueError('Warmup transfer contains non-base parameters')
        for name in ['base_encoder','base_classifier']:
            prefix = name+'.'
            getattr(model,name).load_state_dict({k[len(prefix):]:v for k,v in selected['model_state_dict'].items()
                                                if k.startswith(prefix)}, strict=True)
        result = dict(protocol='harmeme_branch_repair_v2', seed=seed, best_epoch=best_epoch,
                      completed_epoch=epoch, validation=selected['validation'], selected_diagnostics=history[best_epoch-1],
                      checkpoint_sha256=sha256(destination/'best.pt'), transferred_keys=sorted(expected),
                      train_samples=len(datasets['train']), validation_samples=len(datasets['val']),
                      test_evaluated=False, joint_optimizer_reset=True, joint_rng_preserved=True,
                      base_trainable_during_joint=True)
        (destination/'summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
        return result
    finally:
        restore_rng(joint_rng,joint_generator)

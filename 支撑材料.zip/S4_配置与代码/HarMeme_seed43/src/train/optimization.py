"""Optional encoder learning rate; preserve the legacy single-group optimizer."""
import math

import torch


def validate_optimization(training):
    for key in ['learning_rate', 'encoder_learning_rate', 'base_learning_rate']:
        if key in training and (not math.isfinite(training[key]) or training[key] <= 0):
            raise ValueError(f'{key} must be finite and positive')
    if training.get('gradient_clip_scope', 'global') not in {'global', 'optimizer_group'}:
        raise ValueError('gradient_clip_scope must be global or optimizer_group')


def build_optimizer(model, training):
    validate_optimization(training)
    head_lr = training['learning_rate']
    weight_decay = training['weight_decay']
    if 'encoder_learning_rate' not in training or model.explanation_encoder is None:
        # The old parameter order and single-group state remain compatible.
        return torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=head_lr, weight_decay=weight_decay)
    encoder = [p for p in model.explanation_encoder.parameters() if p.requires_grad]
    encoder_ids = {id(p) for p in encoder}
    other = [p for p in model.parameters() if p.requires_grad and id(p) not in encoder_ids]
    if 'base_learning_rate' in training and model.config.use_base:
        base = [p for module in [model.base_encoder, model.base_classifier] for p in module.parameters() if p.requires_grad]
        base_ids = {id(p) for p in base}
        other = [p for p in other if id(p) not in base_ids]
        groups = [
            dict(params=encoder, lr=training['encoder_learning_rate'], name='roberta'),
            dict(params=base, lr=training['base_learning_rate'], name='base'),
            dict(params=other, lr=head_lr, name='fusion_and_explanation_heads')]
        return torch.optim.AdamW([g for g in groups if g['params']], weight_decay=weight_decay)
    return torch.optim.AdamW([
        dict(params=encoder, lr=training['encoder_learning_rate'], name='roberta'),
        dict(params=other, lr=head_lr, name='other_layers')], weight_decay=weight_decay)


def optimizer_description(optimizer):
    return [dict(name=group.get('name', 'all_layers'), learning_rate=group['lr'],
                 parameter_count=sum(p.numel() for p in group['params'])) for group in optimizer.param_groups]


def gradient_norms(optimizer):
    return {group.get('name', 'all_layers'): math.sqrt(sum(float(p.grad.detach().square().sum())
            for p in group['params'] if p.grad is not None)) for group in optimizer.param_groups}


def clip_gradients(model, optimizer, training):
    """Keep a large encoder gradient from setting the clip scale of every head."""
    limit = training['gradient_clip']
    if training.get('gradient_clip_scope', 'global') == 'global':
        norm = torch.nn.utils.clip_grad_norm_(model.parameters(), limit, error_if_nonfinite=True)
        return {'all_layers': min(1., limit / (float(norm) + 1e-6))}
    factors = {}
    for group in optimizer.param_groups:
        norm = torch.nn.utils.clip_grad_norm_(group['params'], limit, error_if_nonfinite=True)
        factors[group['name']] = min(1., limit / (float(norm) + 1e-6))
    return factors

"""Diagnostics that do not alter gradients, RNG state, or model selection."""
import hashlib
import json
from pathlib import Path
import numpy as np
import torch
from src.data.epc_data import sha256


def state_fingerprint(model, prefixes=None):
    h = hashlib.sha256()
    for name, value in model.state_dict().items():
        if prefixes is not None and not name.startswith(prefixes):
            continue
        h.update(name.encode()); h.update(str(tuple(value.shape)).encode())
        h.update(value.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()


def probability_quality(labels, probabilities):
    y, p = np.asarray(labels), np.asarray(probabilities, dtype=np.float64)
    q = p.clip(1e-7, 1-1e-7)
    bins = np.minimum((p*10).astype(int), 9)
    ece = sum(float((bins == b).mean()) * abs(float(p[bins == b].mean()) - float(y[bins == b].mean()))
              for b in range(10) if (bins == b).any())
    return dict(cross_entropy=float(-(y*np.log(q)+(1-y)*np.log(1-q)).mean()),
                brier=float(((p-y)**2).mean()), ece_10_equal_width=ece,
                extreme_probability_fraction=float(((p < .1) | (p > .9)).mean()))


def gradient_probe(model, parts, loss_config):
    """One existing training batch: no forward pass, .grad writes, or RNG draws.

    Gradients are measured on the base encoder and explanation projection only;
    this is not a claim about the entire RoBERTa gradient direction.
    """
    result = {}
    for name, module, auxiliary in [
        ('base_encoder', model.base_encoder, loss_config.alpha*parts['base']),
        ('explanation_projection', model.explanation_projection, loss_config.lambda_explanation*parts['explanation'])]:
        params = [p for p in module.parameters() if p.requires_grad]
        if not params:
            result[name] = dict(frozen=True)
            continue
        objectives = {'fused':parts['fused'], 'weighted_auxiliary':auxiliary,
                      'weighted_consistency':loss_config.gamma*parts['consistency'],
                      'weighted_gate':loss_config.beta*parts['gate']}
        vectors = {}
        for key, loss in objectives.items():
            grad = torch.autograd.grad(loss, params, retain_graph=True, allow_unused=True) if loss.requires_grad else [None]*len(params)
            vectors[key] = torch.cat([(g.detach() if g is not None else torch.zeros_like(p)).reshape(-1)
                                       for p,g in zip(params,grad)])
        item = {key+'_norm':float(v.norm()) for key,v in vectors.items()}
        for key in ['fused','weighted_consistency','weighted_gate']:
            a,b = vectors[key],vectors['weighted_auxiliary']
            denominator = float(a.norm()*b.norm())
            item[key+'_vs_auxiliary_cosine'] = float(torch.dot(a,b)/denominator) if denominator > 1e-20 else None
        result[name] = item
    return result


def import_shared_warmup(model, bundle, settings, seed):
    path = Path(settings['pretrained_checkpoint'])
    if sha256(path) != settings['checkpoint_sha256']:
        raise ValueError('Shared warmup checksum differs')
    checkpoint = torch.load(path, map_location='cpu', weights_only=True)
    expected_settings = {k:v for k,v in settings.items() if k not in {'pretrained_checkpoint','checkpoint_sha256'}}
    if checkpoint['seed'] != seed or checkpoint['cache_sha256'] != bundle['metadata']['bundle_sha256']:
        raise ValueError('Shared warmup seed/cache differs')
    if checkpoint['settings'] != expected_settings:
        raise ValueError('Shared warmup settings differ')
    expected = {k for k in model.state_dict() if k.startswith(('base_encoder.','base_classifier.'))}
    if set(checkpoint['model_state_dict']) != expected:
        raise ValueError('Shared warmup has unexpected parameters')
    for name in ['base_encoder','base_classifier']:
        prefix = name+'.'
        getattr(model,name).load_state_dict({k[len(prefix):]:v for k,v in checkpoint['model_state_dict'].items()
                                            if k.startswith(prefix)}, strict=True)
    info = json.loads(path.with_name('summary.json').read_text('utf-8'))
    return dict(**{k:v for k,v in info.items() if k != 'base_trainable_during_joint'},
                shared_checkpoint=str(path), base_gradient_mode=model.config.base_gradient_mode,
                base_trainable_during_joint=model.config.base_gradient_mode != 'frozen')

"""Branch and inference-intervention diagnostics; never select on test metrics."""
import numpy as np
import torch


@torch.no_grad()
def fusion_columns(model, output):
    hb, he = output['base_representation'], output['explanation_representation']
    c = output['confidence']
    zero_base = torch.zeros_like(hb)
    zero_confidence = (model.base_classifier(zero_base)/model.config.temperature).softmax(-1).amax(-1,keepdim=True)
    alternatives = {
        'without_base': model.fuse_evidence(zero_base, he, zero_confidence),
        'without_explanation': model.fuse_evidence(hb, torch.zeros_like(he), c),
        'static_gate': model.fuse_evidence(hb, he, c, static_gate=.5),
        'without_prototypes': model.fuse_evidence(hb, he, c, disable_prototypes=True),
    }
    columns = {k+'_probability':v['logits'].softmax(-1)[:,1] for k,v in alternatives.items()}
    for key, value in [('base_rms',hb), ('explanation_rms',he),
                       ('fusion_base_rms',output.get('fusion_base_representation',hb)),
                       ('fusion_explanation_rms',output.get('fusion_explanation_representation',he)),
                       ('gated_explanation_rms',output['gate']*output.get('fusion_explanation_representation',he)),
                       ('prototype_residual_rms',output['prototype_residual'])]:
        columns[key] = value.square().mean(-1).sqrt()
    columns['gate_feature_std'] = output['gate'].std(-1,unbiased=False)
    return {k:v.cpu().tolist() for k,v in columns.items()}


def summarize_fusion(rows):
    from src.train.train_epc_ecn import metrics
    labels = [r['label'] for r in rows]
    fused = np.array([r['probability'] for r in rows])
    result = {'branches':{}, 'inference_interventions':{}, 'warnings':[],
              'interpretation':'Interventions zero internal evidence or fix gates at inference; these are not separately trained ablations.'}
    for name,key in [('fused','probability'),('base','base_probability'),('explanation','explanation_probability')]:
        if key not in rows[0]: continue
        p = np.array([r[key] for r in rows])
        result['branches'][name] = dict(**metrics(labels,p), positive_predictions=int((p>=.5).sum()),
             sample_count=len(p), probability_min=float(p.min()), probability_max=float(p.max()), probability_std=float(p.std()))
        if not (p>=.5).any() or (p>=.5).all():
            result['warnings'].append(name+'_predicts_only_one_class_at_0.5')
    for name in ['without_base','without_explanation','static_gate','without_prototypes']:
        key = name+'_probability'
        if key not in rows[0]: continue
        p = np.array([r[key] for r in rows])
        result['inference_interventions'][name] = dict(**metrics(labels,p),
            mean_absolute_probability_change=float(np.abs(p-fused).mean()))
    result['representation_and_gate'] = {k:float(np.mean([r[k] for r in rows])) for k in
        ['base_rms','explanation_rms','fusion_base_rms','fusion_explanation_rms','gated_explanation_rms','prototype_residual_rms','gate_mean','gate_feature_std'] if k in rows[0]}
    return result

"""Train EPC-ECN; validation AUROC selects checkpoints; epoch test reporting is optional."""
import argparse
from dataclasses import asdict
import json
import random
import sys
import time
from pathlib import Path

import numpy as np
import torch
import yaml
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
from torch.utils.data import DataLoader

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from src.data.epc_data import EvidenceCollator, EvidenceDataset, load_bundle, sha256
from src.data.rationale_cache import valid_explanation
from src.models.epc_ecn import EPCConfig, EPCECN, LossConfig, apply_ablation, epc_loss
from src.train.checkpointing import save_checkpoint, capture_rng, restore_rng, validate_continuation
from src.train.optimization import build_optimizer, gradient_norms, optimizer_description, validate_optimization, clip_gradients
from src.train.base_warmup import warmup_base, validate_warmup
from src.train.fusion_health import fusion_columns, summarize_fusion
from src.train.explanation_health import ExplanationMonitor, validate_monitor
from src.train.epoch_testing import epoch_test_enabled, test_and_save_epoch
from src.train.training_controls import build_scheduler, encoder_dropout_options, learning_rates, scheduler_settings
from src.train.controlled_diagnostics import probability_quality, gradient_probe, state_fingerprint, import_shared_warmup


def resolve(path):
    path = Path(path)
    return path if path.is_absolute() else ROOT / path


def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def model_inputs(batch, device):
    return {k: batch[k].to(device) for k in ['image', 'text', 'input_ids', 'attention_mask'] if k in batch}


def metrics(labels, probability):
    labels, probability = np.asarray(labels), np.asarray(probability)
    if not np.isin(labels, [0, 1]).all():
        return None
    pred = probability >= 0.5
    return dict(accuracy=float(accuracy_score(labels, pred)), f1=float(f1_score(labels, pred, zero_division=0)),
                macro_f1=float(f1_score(labels, pred, average='macro', zero_division=0)),
                **probability_quality(labels, probability),
                auroc=float(roc_auc_score(labels, probability)) if len(np.unique(labels)) == 2 else None)


@torch.no_grad()
def evaluate(model, loader, device):
    model.eval()
    rows = []
    for batch in loader:
        out = model(**model_inputs(batch, device))
        diagnostics = fusion_columns(model, out) if model.dual else {}
        probabilities = out['logits'].softmax(-1)[:, 1].cpu().tolist()
        for i, sample_id in enumerate(batch['ids']):
            row = dict(id=sample_id, label=int(batch['labels'][i]), probability=probabilities[i],
                       prediction=int(probabilities[i] >= 0.5))
            if 'base_logits' in out:
                pb = out['base_logits'][i].softmax(-1)
                pt = (out['base_logits'][i] / model.config.temperature).softmax(-1)
                row.update(base_probability=float(pb[1]), confidence=float(out['confidence'][i, 0]),
                           normalized_entropy=float(-(pt * pt.clamp_min(1e-12).log()).sum() / np.log(2)))
            if 'explanation_logits' in out:
                row['explanation_probability'] = float(out['explanation_logits'][i].softmax(-1)[1])
            if 'gate' in out:
                row['gate_mean'] = float(out['gate'][i].mean())
            row.update({key:values[i] for key,values in diagnostics.items()})
            if 'base_gate' in out:
                row['base_gate_mean'] = float(out['base_gate'][i].mean())
            if 'explanation_token_attention' in out:
                attention = out['explanation_token_attention'][i]
                row['pool_attention_entropy'] = float(-(attention * attention.clamp_min(1e-12).log()).sum())
            rows.append(row)
    return metrics([r['label'] for r in rows], [r['probability'] for r in rows]), rows


def save_validation_rows(path, rows, epoch):
    """Persist validation predictions without another forward pass or any test access."""
    import csv
    temporary = path.with_suffix('.csv.tmp')
    with temporary.open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=['epoch', *rows[0]])
        writer.writeheader()
        writer.writerows(dict(epoch=epoch, **row) for row in rows)
    temporary.replace(path)


PAPER_COUNTS = {'harmc': {'train': {0: 1949, 1: 1064}, 'val': {0: 116, 1: 61}, 'test': {0: 230, 1: 124}},
                'fhm': {'train': {0: 5450, 1: 3050}, 'val': {0: 250, 1: 250}, 'test': {0: 563, 1: 437}},
                'harmeme': {'train': {0: 3483, 1: 2550}, 'val': {0: 207, 1: 147}, 'test': {0: 412, 1: 297}}}


def check_bundle(bundle, config, model_config):
    if bundle['image'].shape[1] != model_config.clip_dim:
        raise ValueError('CLIP dimension differs from model configuration')
    if bundle['metadata'].get('dataset') != config['data']['dataset']:
        raise ValueError('Dataset configuration differs from cache provenance')
    if model_config.use_explanation:
        required_protocol = config['data'].get('require_explanation_protocol')
        if required_protocol and (bundle['metadata'].get('explanation_protocol') != required_protocol
                                  or not bundle['metadata'].get('verified_generated_explanations')):
            raise ValueError('Cache lacks the configured, verified explanation generation protocol')
        invalid = [str(sample_id) for sample_id, value in zip(bundle['ids'], bundle['rationales'])
                   if not valid_explanation(value)]
        if invalid:
            raise ValueError(f'{len(invalid)} explanations still need repair. Run generate_epc_rationales.py '
                             f'in PyCharm with Parameters: --execute. Example IDs: {invalid[:10]}')
        if config['data'].get('require_paper_explanations', True):
            if not bundle['metadata'].get('paper_explanations', False):
                raise ValueError('This configuration requires fully paper-generated explanations; '
                                 'use the default legacy-repair configuration for mixed caches.')
        elif config['data'].get('require_repaired_explanations', False):
            if not bundle['metadata'].get('repaired_explanations', False):
                raise ValueError('Cache lacks completed, audited repair provenance. Finish the explanation repair workflow.')
    checked_splits = ['train', 'val', 'test'] if epoch_test_enabled(config.get('training', {})) else ['train', 'val']
    for split in checked_splits:
        labels = bundle['labels'][bundle['splits'] == split]
        if set(labels.tolist()) != {0, 1}:
            raise ValueError(f'{split} requires both labelled classes')
        if config['data'].get('require_paper_counts', True):
            found = {int(k): int(v) for k, v in zip(*np.unique(labels, return_counts=True))}
            expected = PAPER_COUNTS[config['data']['dataset']][split]
            if found != expected:
                raise ValueError(f'{split} counts {found} differ from paper {expected}')


def validate_early_stopping(training):
    patience = training.get('early_stopping_patience', 0)
    if isinstance(patience, bool) or not isinstance(patience, int) or patience < 0:
        raise ValueError('early_stopping_patience must be a nonnegative integer (0 disables it)')
    return patience


def train(config, seed, ablation='full', prototypes=None, output_dir=None, resume=None, warm_start=None):
    from transformers import AutoModel, AutoTokenizer, RobertaConfig
    if resume and warm_start:
        raise ValueError('Choose resume or warm_start, not both')
    seed_everything(seed)
    torch.set_num_threads(config['training'].get('cpu_threads', 4))
    mc, lc = EPCConfig(**config['model']), LossConfig(**config['loss'])
    apply_ablation(mc, lc, ablation)
    if prototypes is not None:
        if prototypes < 1:
            raise ValueError('Prototype count must be positive')
        mc.num_prototypes = prototypes
    bundle = load_bundle(resolve(config['data']['cache']))
    check_bundle(bundle, config, mc)
    tc = config['training']
    test_each_epoch = epoch_test_enabled(tc)
    validate_optimization(tc)
    validate_warmup(config.get('base_warmup', {}))
    scheduling = scheduler_settings(tc)
    dropout_options = encoder_dropout_options(config.get('roberta', {}))
    patience = validate_early_stopping(tc)
    monitor_settings = validate_monitor(config, mc)
    if tc['epochs'] < 1 or tc['batch_size'] < 1 or tc['gradient_clip'] <= 0:
        raise ValueError('Epochs, batch size and gradient clip must be positive')
    device_name = tc['device']
    if device_name == 'auto':
        device_name = 'cuda' if torch.cuda.is_available() else 'cpu'
    device = torch.device(device_name)
    outdir = resolve(output_dir or config['output_dir']) / ablation / f'k{mc.num_prototypes}' / f'seed_{seed}'
    if outdir.exists():
        raise FileExistsError(f'Refusing to overwrite an existing run: {outdir}')
    source = resolve(resume or warm_start) if (resume or warm_start) else None
    continuation = torch.load(source, map_location='cpu', weights_only=True) if source else None
    if continuation is not None:
        validate_continuation(continuation, config, mc.to_dict(), asdict(lc), bundle, seed, ablation, bool(resume))
        if resume and patience and continuation['epoch'] - continuation['best_epoch'] >= patience:
            raise ValueError('Early stopping patience is already exhausted in this checkpoint; '
                             'increase early_stopping_patience or set it to 0 to continue explicitly')
    log_every = int(tc.get('log_every_steps', 0))
    if log_every < 0:
        raise ValueError('log_every_steps must be nonnegative')
    print(f'Training setup: device={device}; seed={seed}; batch_size={tc["batch_size"]}; '
          f'epochs={tc["epochs"]}; cpu_threads={torch.get_num_threads()}', flush=True)
    if patience:
        print(f'Early stopping: validation AUROC; patience={patience}; only a strict improvement resets the counter.', flush=True)
    if scheduling is not None:
        print(f'Learning-rate decay: validation AUROC; reduce after {scheduling["patience"] + 1} '
              f'consecutive non-improving epochs; factor={scheduling["factor"]}; '
              f'minimum={scheduling["min_lr_ratio"]} of each initial group rate.', flush=True)
    tokenizer, encoder = None, None
    if mc.use_explanation:
        # Reject invalid text before loading 500 MB of transformer weights.
        for split in ['train', 'val']:
            texts = bundle['rationales'][bundle['splits'] == split]
            if any(not x.strip() or x.lower().startswith('error') for x in texts):
                raise ValueError(f'{split}: missing/invalid explanations; see cache audit')
        rc = config['roberta']
        print('Loading RoBERTa and tokenizer...', flush=True)
        if continuation is not None:
            tokenizer = AutoTokenizer.from_pretrained(source.parent / 'tokenizer', local_files_only=True)
            encoder = AutoModel.from_config(RobertaConfig.from_dict(continuation['roberta_config']))
        else:
            tokenizer = AutoTokenizer.from_pretrained(rc['name_or_path'], local_files_only=rc.get('local_files_only', True))
            encoder = AutoModel.from_pretrained(rc['name_or_path'], local_files_only=rc.get('local_files_only', True),
                                               **dropout_options)
        if encoder.config.model_type != 'roberta':
            raise ValueError('The paper requires a RoBERTa explanation encoder')
        encoder.requires_grad_(True)
        if rc.get('gradient_checkpointing', False):
            encoder.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant': False})
            print('RoBERTa activation checkpointing enabled: lower memory use, extra recomputation.', flush=True)
    datasets = {s: EvidenceDataset(bundle, s, tokenizer, config['data']['explanation_max_length']) for s in ['train', 'val']}
    loader_args = dict(num_workers=tc['num_workers'], collate_fn=EvidenceCollator(tokenizer), pin_memory=device.type == 'cuda')
    train_generator = torch.Generator().manual_seed(seed)
    train_loader = DataLoader(datasets['train'], batch_size=tc['batch_size'], shuffle=True,
                              generator=train_generator, **loader_args)
    val_loader = DataLoader(datasets['val'], batch_size=tc['eval_batch_size'], shuffle=False, **loader_args)
    test_loader = None
    if test_each_epoch:
        test_dataset = EvidenceDataset(bundle, 'test', tokenizer, config['data']['explanation_max_length'])
        # DataLoader iteration otherwise draws a base seed from the global RNG,
        # changing dropout in subsequent training epochs even with shuffle=False.
        test_loader = DataLoader(test_dataset, batch_size=tc['eval_batch_size'], shuffle=False,
                                 generator=torch.Generator().manual_seed(seed), **loader_args)
    model = EPCECN(mc, encoder).to(device)
    optimizer = build_optimizer(model, tc)
    scheduler = build_scheduler(optimizer, tc)
    start_epoch, best_auc, best_epoch = 1, -float('inf'), -1
    initial_best = None
    if continuation is not None:
        model.load_state_dict(continuation['model_state_dict'], strict=True)
        start_epoch = continuation['epoch'] + 1
        if resume:
            optimizer.load_state_dict(continuation['optimizer_state_dict'])
            if scheduler is not None:
                scheduler.load_state_dict(continuation['lr_scheduler_state_dict'])
            best_auc, best_epoch = continuation['best_auc'], continuation['best_epoch']
            if best_epoch == continuation['epoch']:
                initial_best = continuation
            else:
                initial_best = torch.load(continuation['best_checkpoint'], map_location='cpu', weights_only=True)
                if initial_best['epoch'] != best_epoch or initial_best['validation']['auroc'] != best_auc:
                    raise ValueError('Saved best checkpoint does not match continuation state')
        else:
            best_auc, best_epoch = continuation['validation']['auroc'], continuation['epoch']
            initial_best = continuation
            if scheduler is not None:
                # A weights-only warm start resets the scheduler, but the
                # inherited validation score is still the improvement baseline.
                scheduler.step(best_auc)
            print('Warm start: keeping saved model weights; AdamW and RNG are reset. This is recorded in run.json.', flush=True)
    outdir.mkdir(parents=True)
    if tokenizer is not None:
        tokenizer.save_pretrained(outdir / 'tokenizer')
    warmup_info = continuation['run'].get('base_warmup') if continuation is not None else None
    if continuation is None and config.get('base_warmup', {}).get('enabled', False):
        if config['base_warmup'].get('pretrained_checkpoint'):
            warmup_info = import_shared_warmup(model, bundle, config['base_warmup'], seed)
        else:
            warmup_info = warmup_base(model, bundle, config['base_warmup'], seed, device,
                                      outdir / 'base_warmup', train_generator)
    run = dict(config=config, model=mc.to_dict(), loss=asdict(lc), seed=seed, ablation=ablation,
               torch_version=str(torch.__version__), device=str(device), cache_metadata=bundle['metadata'],
               optimizer_groups=optimizer_description(optimizer))
    run['base_warmup'] = warmup_info
    if config.get('controlled_diagnostics', False):
        run['initialization'] = (continuation['run']['initialization'] if continuation is not None else
            dict(full_state_sha256=state_fingerprint(model),
                 base_state_sha256=state_fingerprint(model, ('base_encoder.','base_classifier.'))))
    print('Optimizer groups: ' + json.dumps(run['optimizer_groups']), flush=True)
    if continuation is not None:
        run['continuation'] = dict(mode='resume' if resume else 'warm_start', checkpoint=str(source.resolve()),
                                   checkpoint_sha256=sha256(source), completed_epoch=continuation['epoch'],
                                   optimizer_reset=not bool(resume), rng_reset=not bool(resume),
                                   previous_continuation=continuation['run'].get('continuation'))
    (outdir / 'run.json').write_text(json.dumps(run, ensure_ascii=False, indent=2), encoding='utf-8')
    best_path, last_path = outdir / 'best.pt', None
    if initial_best is not None:
        inference_keys = ['schema_version', 'model_state_dict', 'model_config', 'roberta_config',
                          'loss_config', 'run', 'epoch', 'validation', 'explanation_max_length']
        if 'explanation_monitor_state' in initial_best:
            inference_keys.append('explanation_monitor_state')
        if 'lr_scheduler_state_dict' in initial_best:
            inference_keys.append('lr_scheduler_state_dict')
        best_path = save_checkpoint({k: initial_best[k] for k in inference_keys}, best_path)
        import shutil
        previous_best_folder = Path(continuation['best_checkpoint']).parent if resume else source.parent
        previous_rows = previous_best_folder / f'validation_epoch_{best_epoch:03d}.csv'
        if not previous_rows.exists():
            previous_rows = previous_best_folder / 'validation_best.csv'
        if previous_rows.is_file():
            shutil.copyfile(previous_rows, outdir / 'validation_best.csv')
        del initial_best
    if resume:
        restore_rng(continuation['rng_state'], train_generator)
    if config.get('controlled_diagnostics', False):
        diagnostic_rng = capture_rng(train_generator)
        initial_metrics, initial_rows = evaluate(model, val_loader, device)
        save_validation_rows(outdir/'validation_initial.csv', initial_rows, start_epoch-1)
        (outdir/'fusion_health_initial.json').write_text(json.dumps(summarize_fusion(initial_rows),indent=2), 'utf-8')
        restore_rng(diagnostic_rng, train_generator)
    monitor = None
    if monitor_settings.get('enabled', False):
        previous_monitor = continuation.get('explanation_monitor_state') if continuation is not None else None
        if resume and previous_monitor is None:
            raise ValueError('Resume checkpoint lacks the saved explanation monitor reference')
        monitor = ExplanationMonitor(monitor_settings, datasets['val'], loader_args['collate_fn'], outdir, device, previous_monitor)
        monitor.observe(model, start_epoch - 1, 0, (start_epoch - 1) * len(train_loader),
                        phase='continuation' if continuation is not None else 'initial')
    del continuation
    for epoch in range(start_epoch, tc['epochs'] + 1):
        model.train()
        epoch_learning_rates = learning_rates(optimizer) if scheduler is not None else None
        sums = {}
        epoch_started = time.perf_counter()
        print(f'Epoch {epoch}/{tc["epochs"]}: training {len(train_loader)} batches...', flush=True)
        for step, batch in enumerate(train_loader, 1):
            optimizer.zero_grad(set_to_none=True)
            outputs = model(**model_inputs(batch, device))
            loss, parts = epc_loss(model, outputs, batch['labels'].to(device), lc)
            if not torch.isfinite(loss):
                raise FloatingPointError(f'Nonfinite loss at epoch {epoch}')
            if config.get('controlled_diagnostics', False) and step == 1:
                diagnostic = dict(epoch=epoch, sample_ids=batch['ids'], gradients=gradient_probe(model, parts, lc))
                with (outdir/'gradient_routes.jsonl').open('a',encoding='utf-8') as stream:
                    stream.write(json.dumps(diagnostic)+'\n')
            loss.backward()
            record_step = step == 1 or step == len(train_loader) or (log_every > 0 and step % log_every == 0)
            step_record = None
            if monitor is not None and record_step:
                step_record = dict(epoch=epoch, step=step, global_step=(epoch-1)*len(train_loader)+step,
                                   losses={k: float(v.detach()) for k, v in dict(total=loss, **parts).items()},
                                   gradient_norms_before_clip=gradient_norms(optimizer))
            clipping = clip_gradients(model, optimizer, tc)
            if step_record is not None:
                step_record['gradient_clip_factors'] = clipping
                step_record['gradient_norms_after_clip'] = gradient_norms(optimizer)
            optimizer.step()
            if step_record is not None:
                with (outdir / 'training_steps.jsonl').open('a', encoding='utf-8') as stream:
                    stream.write(json.dumps(step_record) + '\n')
            for name, value in dict(total=loss, **parts).items():
                sums[name] = sums.get(name, 0.0) + float(value.detach()) * len(batch['labels'])
            if log_every and (step == 1 or step % log_every == 0 or step == len(train_loader)):
                elapsed = time.perf_counter() - epoch_started
                print(f'Epoch {epoch}/{tc["epochs"]} | batch {step}/{len(train_loader)} | '
                      f'loss={float(loss.detach()):.4f} | explanation_loss={float(parts["explanation"].detach()):.4f} | '
                      f'elapsed={elapsed / 60:.1f} min', flush=True)
            if monitor is not None and (step % monitor_settings['every_steps'] == 0 or step == len(train_loader)):
                monitor.observe(model, epoch, step, (epoch-1)*len(train_loader)+step)
        print(f'Epoch {epoch}: evaluating validation set...', flush=True)
        val, val_rows = evaluate(model, val_loader, device)
        if val['auroc'] is None or not np.isfinite(val['auroc']):
            raise ValueError('Validation AUROC is undefined')
        record = dict(epoch=epoch, train_loss={k: v / len(datasets['train']) for k, v in sums.items()}, validation=val)
        record['fusion_health'] = summarize_fusion(val_rows)
        if config.get('controlled_diagnostics', False):
            record['base_state_sha256'] = state_fingerprint(model, ('base_encoder.','base_classifier.'))
            if mc.base_gradient_mode == 'frozen' and record['base_state_sha256'] != run['initialization']['base_state_sha256']:
                raise AssertionError('Frozen base parameters changed')
        (outdir / f'fusion_health_epoch_{epoch:03d}.json').write_text(json.dumps(record['fusion_health'], indent=2), encoding='utf-8')
        if mc.use_base:
            record['validation_base'] = metrics([r['label'] for r in val_rows],
                                                [r['base_probability'] for r in val_rows])
        save_validation_rows(outdir / f'validation_epoch_{epoch:03d}.csv', val_rows, epoch)
        if mc.use_explanation:
            labels = np.asarray([r['label'] for r in val_rows])
            probabilities = np.asarray([r['explanation_probability'] for r in val_rows])
            clipped = probabilities.clip(1e-7, 1-1e-7)
            record['validation_explanation'] = dict(**metrics(labels, probabilities), sample_count=len(labels),
                probability_std=float(probabilities.std()), probability_min=float(probabilities.min()),
                probability_max=float(probabilities.max()))
        if monitor is not None:
            record['explanation_probe'] = monitor.latest
        if scheduler is not None:
            scheduler.step(val['auroc'])
            record['learning_rates'] = epoch_learning_rates
            record['next_learning_rates'] = learning_rates(optimizer)
            if record['next_learning_rates'] != epoch_learning_rates:
                print(f'Learning rates reduced for the next epoch: {record["next_learning_rates"]}', flush=True)
        print(json.dumps(record), flush=True)
        checkpoint = dict(schema_version=1, model_state_dict=model.state_dict(), model_config=mc.to_dict(),
                          roberta_config=encoder.config.to_dict() if encoder is not None else None,
                          loss_config=asdict(lc), run=run, epoch=epoch, validation=val,
                          explanation_max_length=config['data']['explanation_max_length'])
        if monitor is not None:
            checkpoint['explanation_monitor_state'] = monitor.state_dict()
        if scheduler is not None:
            # Persist after step(), together with the optimizer's updated rates.
            checkpoint['lr_scheduler_state_dict'] = scheduler.state_dict()
        if val['auroc'] > best_auc:
            best_auc, best_epoch = val['auroc'], epoch
            best_path = save_checkpoint(checkpoint, outdir / 'best.pt')
            save_validation_rows(outdir / 'validation_best.csv', val_rows, epoch)
            (outdir / 'fusion_health_best.json').write_text(json.dumps(record['fusion_health'], indent=2), encoding='utf-8')
        last_path = save_checkpoint(dict(**checkpoint, optimizer_state_dict=optimizer.state_dict(),
                                        rng_state=capture_rng(train_generator), best_auc=best_auc,
                                        best_epoch=best_epoch, best_checkpoint=str(best_path.resolve())), outdir / 'last.pt')
        print(f'Latest full training state: {last_path}', flush=True)
        with (outdir / 'history.jsonl').open('a', encoding='utf-8') as stream:
            stream.write(json.dumps(record) + '\n')
        if test_each_epoch:
            # Save the completed training state before the additional CPU test,
            # so an interruption during testing does not lose this epoch's model.
            print(f'Epoch {epoch}: evaluating test set...', flush=True)
            test_and_save_epoch(model, test_loader, device, epoch, seed,
                                bundle['metadata']['bundle_sha256'], outdir, evaluate)
        # best_epoch is stored in last.pt, so resume retains the exact waiting
        # period without introducing a separate counter or changing result schemas.
        if patience:
            waiting = epoch - best_epoch
            print(f'Early stopping: {waiting}/{patience} epochs without improvement; '
                  f'best epoch={best_epoch}; best validation AUROC={best_auc:.6f}', flush=True)
            if waiting >= patience:
                print(f'Early stopping triggered at epoch {epoch}. Best and last checkpoints are saved.', flush=True)
                break
    result = dict(seed=seed, best_epoch=best_epoch, best_validation_auroc=best_auc,
                  checkpoint=str(best_path), last_checkpoint=str(last_path), test_evaluated=test_each_epoch)
    if test_each_epoch:
        result['test_history'] = str(outdir / 'test_history.jsonl')
    if monitor is not None:
        health_path = outdir / 'health_report.json'
        report = dict(seed=seed, completed_epoch=epoch, test_evaluated=test_each_epoch, optimizer_groups=optimizer_description(optimizer),
                      cache_sha256=bundle['metadata']['bundle_sha256'], probe_reference=monitor.state_dict(),
                      final_probe=monitor.latest, validation=val, validation_explanation=record['validation_explanation'],
                      checkpoint=str(best_path), last_checkpoint=str(last_path),
                      interpretation='Exploratory stability check; warnings are advisory. A healthy probe does not establish long-run stability or correct explanation reasoning.')
        health_path.write_text(json.dumps(report, indent=2), encoding='utf-8')
        result['health_report'] = str(health_path)
        print(f'Explanation health report: {health_path}', flush=True)
    (outdir / 'result.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    return result


def fresh_output_dir(path):
    """Select a new experiment root without writing or deleting anything.

    The training loop retains its final no-overwrite check as well. One root is
    chosen for the entire configured seed list, keeping a repeated run together.
    """
    root = resolve(path)
    candidate, attempt = root, 1
    while candidate.exists():
        attempt += 1
        candidate = root.with_name(f'{root.name}_run{attempt}')
    return candidate


def main(default_config=None, auto_output=False):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', default=str(default_config or ROOT / 'experiments/epc_ecn.yaml'))
    parser.add_argument('--seed', type=int, help='One seed; otherwise run all configured seeds')
    parser.add_argument('--ablation', default='full', choices=['full', 'no_explanation', 'no_base', 'no_alignment',
                        'no_epm', 'no_tese', 'no_cecr', 'static_fusion', 'no_diversity'])
    parser.add_argument('--prototypes', type=int)
    parser.add_argument('--output-dir')
    continuation = parser.add_mutually_exclusive_group()
    continuation.add_argument('--resume', help='Continue from last.pt with optimizer and RNG state; use a new output directory')
    continuation.add_argument('--warm-start', help='Continue from saved weights with a fresh optimizer; use a new output directory')
    parser.add_argument('--check-data', action='store_true')
    args = parser.parse_args()
    config = yaml.safe_load(resolve(args.config).read_text(encoding='utf-8'))
    if auto_output:
        # Opt-in for the reusable new-cache launcher only. Other entry points
        # retain their existing strict output-directory behavior.
        output = fresh_output_dir(args.output_dir or config['output_dir'])
        args.output_dir = str(output)
        config['output_dir'] = str(output)
        print(f'Configuration: {resolve(args.config)}', flush=True)
        print(f'Output directory for this run: {output}', flush=True)
    if args.check_data:
        bundle = load_bundle(resolve(config['data']['cache']))
        mc, lc = EPCConfig(**config['model']), LossConfig(**config['loss'])
        apply_ablation(mc, lc, args.ablation)
        validate_optimization(config['training'])
        scheduling = scheduler_settings(config['training'])
        dropout_options = encoder_dropout_options(config.get('roberta', {}))
        patience = validate_early_stopping(config['training'])
        validate_monitor(config, mc)
        check_bundle(bundle, config, mc)
        for split in ['train', 'val']:
            if mc.use_explanation and any(not x.strip() for x in bundle['rationales'][bundle['splits'] == split]):
                raise ValueError(f'{split} has missing explanations')
        print('Data checks passed')
        print(f'Training configuration: epochs={config["training"]["epochs"]}; '
              f'other_lr={config["training"]["learning_rate"]}; '
              f'encoder_lr={config["training"].get("encoder_learning_rate", config["training"]["learning_rate"])}; '
              f'explanation_monitor={config.get("explanation_monitor", {}).get("enabled", False)}; '
              f'early_stopping_patience={patience}; '
              f'evaluate_test_each_epoch={epoch_test_enabled(config["training"])}')
        if scheduling is not None or dropout_options:
            print(f'Additional training controls: scheduler={scheduling}; encoder_dropout={dropout_options}')
        return
    seeds = [args.seed] if args.seed is not None else config['training']['seeds']
    if (args.resume or args.warm_start) and len(seeds) != 1:
        raise ValueError('Continuation requires one seed; specify --seed')
    results = [train(config, seed, args.ablation, args.prototypes, args.output_dir, args.resume, args.warm_start) for seed in seeds]
    print(json.dumps(results, indent=2))


if __name__ == '__main__':
    main()

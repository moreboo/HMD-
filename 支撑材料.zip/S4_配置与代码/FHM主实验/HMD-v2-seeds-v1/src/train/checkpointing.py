"""Closed-file checkpoint commits and explicit training-state recovery."""
import os
import random
import time
import uuid
from pathlib import Path

import numpy as np
import torch


def save_checkpoint(value, destination, attempts=6):
    """Retain a fully written temporary checkpoint if Windows keeps it locked."""
    destination = Path(destination)
    temporary = destination.with_name(destination.stem + '.' + uuid.uuid4().hex + '.tmp')
    with temporary.open('xb') as stream:
        torch.save(value, stream)
        stream.flush()
        os.fsync(stream.fileno())
    for attempt in range(attempts):
        try:
            os.replace(temporary, destination)
            return destination
        except OSError as error:
            if not isinstance(error, PermissionError) and getattr(error, 'winerror', None) not in {32, 33}:
                raise
            if attempt + 1 < attempts:
                time.sleep(min(0.5 * 2 ** attempt, 4.0))
    # Both files are preserved: an older canonical checkpoint is never deleted.
    print(f'Checkpoint rename remains locked. Complete checkpoint retained at: {temporary}', flush=True)
    return temporary


def capture_rng(generator):
    state = np.random.get_state()
    return dict(python=random.getstate(), numpy=dict(name=state[0], keys=state[1].tolist(),
                position=state[2], has_gauss=state[3], cached_gaussian=state[4]),
                torch=torch.get_rng_state(), cuda=torch.cuda.get_rng_state_all() if torch.cuda.is_available() else [],
                train_generator=generator.get_state())


def restore_rng(state, generator):
    random.setstate(state['python'])
    numpy = state['numpy']
    np.random.set_state((numpy['name'], np.asarray(numpy['keys'], dtype=np.uint32),
                         numpy['position'], numpy['has_gauss'], numpy['cached_gaussian']))
    torch.set_rng_state(state['torch'])
    if state['cuda'] and torch.cuda.is_available():
        torch.cuda.set_rng_state_all(state['cuda'])
    generator.set_state(state['train_generator'])


def validate_continuation(checkpoint, config, model_config, loss_config, bundle, seed, ablation, resume):
    if checkpoint.get('schema_version') != 1:
        raise ValueError('Unsupported checkpoint schema')
    if checkpoint['model_config'] != model_config or checkpoint['loss_config'] != loss_config:
        raise ValueError('Continuation model/loss configuration differs from checkpoint')
    previous = checkpoint['run']
    if previous['seed'] != seed or previous['ablation'] != ablation:
        raise ValueError('Continuation seed/ablation differs from checkpoint')
    if previous['cache_metadata']['bundle_sha256'] != bundle['metadata']['bundle_sha256']:
        raise ValueError('Continuation data cache differs from checkpoint')
    for section in ['data', 'roberta']:
        if previous['config'][section] != config[section]:
            raise ValueError(f'Continuation {section} configuration differs from checkpoint')
    # Stopping policy may change on continuation; optimizer/data settings may not.
    permitted = {'epochs', 'log_every_steps', 'seeds', 'early_stopping_patience'}
    before = {k: v for k, v in previous['config']['training'].items() if k not in permitted}
    after = {k: v for k, v in config['training'].items() if k not in permitted}
    if before != after:
        raise ValueError('Continuation training settings differ from checkpoint')
    if previous['config'].get('explanation_monitor', {}) != config.get('explanation_monitor', {}):
        raise ValueError('Continuation explanation monitor settings differ from checkpoint')
    if config['training']['epochs'] <= checkpoint['epoch']:
        raise ValueError('Configured epoch limit is already reached by this checkpoint')
    if resume and not all(k in checkpoint for k in ['optimizer_state_dict', 'rng_state', 'best_auc', 'best_epoch', 'best_checkpoint']):
        raise ValueError('Checkpoint has weights only. Use --warm-start explicitly; optimizer and RNG will be reset.')
    if resume and config.get('explanation_monitor', {}).get('enabled', False) and 'explanation_monitor_state' not in checkpoint:
        raise ValueError('Resume checkpoint lacks the saved explanation monitor reference')
    if resume and config['training'].get('lr_scheduler') is not None and 'lr_scheduler_state_dict' not in checkpoint:
        raise ValueError('Resume checkpoint lacks the saved learning-rate scheduler state')

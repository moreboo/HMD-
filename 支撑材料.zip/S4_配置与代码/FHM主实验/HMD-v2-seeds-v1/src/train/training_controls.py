"""Opt-in regularization and validation-only learning-rate scheduling."""
import math

from torch.optim.lr_scheduler import ReduceLROnPlateau


def _number(value, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
        raise ValueError(f'{name} must be a finite number')
    return float(value)


def encoder_dropout_options(roberta):
    """Override pretrained dropout only when explicitly requested by the YAML."""
    options = {}
    for name in ['hidden_dropout_prob', 'attention_probs_dropout_prob']:
        if name in roberta:
            value = _number(roberta[name], name)
            if not 0 <= value < 1:
                raise ValueError(f'{name} must be at least 0 and below 1')
            options[name] = value
    return options


def scheduler_settings(training):
    settings = training.get('lr_scheduler')
    if settings is None:
        return None
    allowed = {'name', 'factor', 'patience', 'min_lr_ratio'}
    if not isinstance(settings, dict) or set(settings) - allowed:
        raise ValueError('lr_scheduler must contain only name, factor, patience and min_lr_ratio')
    if settings.get('name') != 'reduce_on_plateau':
        raise ValueError('lr_scheduler.name must be reduce_on_plateau')
    factor = _number(settings.get('factor', 0.5), 'lr_scheduler.factor')
    minimum = _number(settings.get('min_lr_ratio', 0.1), 'lr_scheduler.min_lr_ratio')
    patience = settings.get('patience', 1)
    if not 0 < factor < 1:
        raise ValueError('lr_scheduler.factor must be between 0 and 1')
    if not 0 <= minimum <= 1:
        raise ValueError('lr_scheduler.min_lr_ratio must be between 0 and 1 inclusive')
    if isinstance(patience, bool) or not isinstance(patience, int) or patience < 0:
        raise ValueError('lr_scheduler.patience must be a nonnegative integer')
    return dict(factor=factor, patience=patience, min_lr_ratio=minimum)


def build_scheduler(optimizer, training):
    settings = scheduler_settings(training)
    if settings is None:
        return None
    # PyTorch reduces after patience + 1 consecutive non-improving epochs.
    # Use the same strict AUROC improvement rule as best-model selection.
    return ReduceLROnPlateau(optimizer, mode='max', factor=settings['factor'],
        patience=settings['patience'], threshold=0.0, threshold_mode='abs', cooldown=0,
        min_lr=[group['lr'] * settings['min_lr_ratio'] for group in optimizer.param_groups], eps=0.0)


def learning_rates(optimizer):
    return {group.get('name', f'group_{index}'): float(group['lr'])
            for index, group in enumerate(optimizer.param_groups)}

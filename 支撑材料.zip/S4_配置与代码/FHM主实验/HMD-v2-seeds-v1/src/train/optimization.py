"""Optional encoder learning rate; preserve the legacy single-group optimizer."""
import math

import torch


def validate_optimization(training):
    for key in ['learning_rate', 'encoder_learning_rate']:
        if key in training and (not math.isfinite(training[key]) or training[key] <= 0):
            raise ValueError(f'{key} must be finite and positive')


def build_optimizer(model, training):
    validate_optimization(training)
    head_lr = training['learning_rate']
    weight_decay = training['weight_decay']
    if 'encoder_learning_rate' not in training or model.explanation_encoder is None:
        # The old parameter order and single-group state remain compatible.
        return torch.optim.AdamW(model.parameters(), lr=head_lr, weight_decay=weight_decay)
    encoder = list(model.explanation_encoder.parameters())
    encoder_ids = {id(p) for p in encoder}
    other = [p for p in model.parameters() if id(p) not in encoder_ids]
    return torch.optim.AdamW([
        dict(params=encoder, lr=training['encoder_learning_rate'], name='roberta'),
        dict(params=other, lr=head_lr, name='other_layers')], weight_decay=weight_decay)


def optimizer_description(optimizer):
    return [dict(name=group.get('name', 'all_layers'), learning_rate=group['lr'],
                 parameter_count=sum(p.numel() for p in group['params'])) for group in optimizer.param_groups]


def gradient_norms(optimizer):
    return {group.get('name', 'all_layers'): math.sqrt(sum(float(p.grad.detach().square().sum())
            for p in group['params'] if p.grad is not None)) for group in optimizer.param_groups}

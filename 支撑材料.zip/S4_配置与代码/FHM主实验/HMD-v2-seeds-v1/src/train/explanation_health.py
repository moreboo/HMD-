"""Validation-only branch probes that do not alter training RNG or gradients."""
import json

import numpy as np
import torch


def validate_monitor(config, model_config):
    settings = config.get('explanation_monitor', {})
    if settings.get('enabled', False):
        if not model_config.use_explanation:
            raise ValueError('Explanation monitoring requires the explanation branch')
        for key, minimum in [('every_steps', 1), ('probe_size', 2)]:
            value = settings.get(key)
            if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
                raise ValueError(f'explanation_monitor.{key} must be an integer >= {minimum}')
    return settings


def health_warnings(probability_std, probability_range, spread_retention, swap_change, distinct_inputs):
    """Advisory engineering thresholds, not a statistical test or paper criterion."""
    if distinct_inputs < 2:
        return ['insufficient_distinct_inputs']
    warnings = []
    # Separate signals avoid the old AND rule missing a near-constant output.
    if probability_std < 1e-4 and probability_range < 1e-3:
        warnings.append('near_constant_explanation_probability')
    if spread_retention is not None and spread_retention < 0.01:
        warnings.append('explanation_representation_contracted')
    if swap_change < 1e-4:
        warnings.append('low_sensitivity_to_explanation_swaps')
    return warnings


@torch.no_grad()
def probe_explanations(model, batch, device, initial_spread=None):
    was_training = model.training
    device = torch.device(device)
    cuda_devices = [device.index if device.index is not None else torch.cuda.current_device()] if device.type == 'cuda' else []
    try:
        with torch.random.fork_rng(devices=cuda_devices):
            model.eval()
            inputs = {k: batch[k].to(device) for k in ['image', 'text', 'input_ids', 'attention_mask']}
            output = model(**inputs)
            he = output['explanation_representation'].float()
            spread = float((he - he.mean(0)).square().mean().sqrt())
            magnitude = float(he.square().mean().sqrt())
            relative_spread = spread / max(magnitude, 1e-30)
            probability = output['explanation_logits'].softmax(-1)[:, 1]
            changes = []
            for anchor in sorted(set(np.linspace(0, len(he) - 1, min(4, len(he)), dtype=int).tolist())):
                swapped = dict(inputs, image=inputs['image'][anchor:anchor+1].expand_as(inputs['image']),
                               text=inputs['text'][anchor:anchor+1].expand_as(inputs['text']))
                p = model(**swapped)['logits'].softmax(-1)[:, 1]
                changes.append(float((p - p[anchor]).abs().max()))
            retention = relative_spread / max(initial_spread, 1e-30) if initial_spread is not None else None
            result = dict(monitor_version=1, sample_count=len(he),
                          explanation_loss=float(torch.nn.functional.cross_entropy(output['explanation_logits'], batch['labels'].to(device))),
                          explanation_probability_std=float(probability.std(unbiased=False)),
                          explanation_probability_min=float(probability.min()), explanation_probability_max=float(probability.max()),
                          representation_rms=spread, representation_relative_spread=relative_spread,
                          spread_retention=retention, swap_max_probability_change=max(changes),
                          swap_mean_anchor_max_change=float(np.mean(changes)),
                          unique_token_sequences=len({tuple(r[m.bool()].tolist()) for r, m in zip(batch['input_ids'], batch['attention_mask'])}))
            result['warnings'] = health_warnings(result['explanation_probability_std'],
                result['explanation_probability_max'] - result['explanation_probability_min'], retention,
                result['swap_max_probability_change'], result['unique_token_sequences'])
            return result
    finally:
        model.train(was_training)


class ExplanationMonitor:
    def __init__(self, settings, dataset, collator, output_dir, device, previous=None):
        self.settings, self.output_dir, self.device = settings, output_dir, device
        indices = np.linspace(0, len(dataset) - 1, min(settings['probe_size'], len(dataset)), dtype=int)
        self.batch = collator([dataset[int(i)] for i in indices])
        if previous is not None:
            if previous.get('monitor_version') != 1 or previous['probe_ids'] != self.batch['ids']:
                raise ValueError('Saved explanation monitor does not match the validation probe')
            self.initial_spread = previous['initial_spread']
        else:
            self.initial_spread = None
        self.latest = None

    def observe(self, model, epoch, step, global_step, phase='training'):
        result = probe_explanations(model, self.batch, self.device, self.initial_spread)
        if self.initial_spread is None:
            self.initial_spread = result['representation_relative_spread']
        result.update(epoch=epoch, step=step, global_step=global_step, phase=phase)
        with (self.output_dir / 'explanation_health.jsonl').open('a', encoding='utf-8') as stream:
            stream.write(json.dumps(result) + '\n')
        print('Explanation probe: ' + json.dumps(result), flush=True)
        if result['warnings']:
            print('Explanation warning (advisory): ' + ', '.join(result['warnings']), flush=True)
        self.latest = result
        return result

    def state_dict(self):
        return dict(monitor_version=1, probe_ids=self.batch['ids'], initial_spread=self.initial_spread)

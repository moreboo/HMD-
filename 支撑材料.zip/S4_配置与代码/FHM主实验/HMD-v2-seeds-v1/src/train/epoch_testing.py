"""Optional per-epoch test observations; never used to choose or train a model."""
import json
from pathlib import Path

import pandas as pd
import torch


def epoch_test_enabled(training):
    enabled = training.get('evaluate_test_each_epoch', False)
    if not isinstance(enabled, bool):
        raise ValueError('evaluate_test_each_epoch must be true or false')
    return enabled


def test_and_save_epoch(model, loader, device, epoch, seed, cache_hash, output_dir, evaluate_fn):
    """Use the normal evaluator and restore RNG/mode even if evaluation fails."""
    device = torch.device(device)
    devices = [device.index if device.index is not None else torch.cuda.current_device()] if device.type == 'cuda' else []
    was_training = model.training
    try:
        with torch.random.fork_rng(devices=devices):
            scores, rows = evaluate_fn(model, loader, device)
    finally:
        model.train(was_training)
    report = dict(epoch=epoch, seed=seed, split='test', threshold=0.5,
                  sample_count=len(rows), metrics=scores, cache_sha256=cache_hash)
    # Per-epoch weights are not retained. Identify this evaluation by epoch,
    # rather than pointing at last.pt, whose contents change on the next epoch.
    output_dir = Path(output_dir)
    target = output_dir / 'epoch_tests' / f'epoch_{epoch:03d}'
    target.mkdir(parents=True, exist_ok=False)
    with (target / 'predictions.csv').open('x', encoding='utf-8', newline='') as stream:
        pd.DataFrame(rows).to_csv(stream, index=False)
    with (target / 'metrics.json').open('x', encoding='utf-8') as stream:
        json.dump(report, stream, indent=2)
    with (output_dir / 'test_history.jsonl').open('a', encoding='utf-8') as stream:
        stream.write(json.dumps(report) + '\n')
    print(json.dumps(dict(epoch=epoch, test=scores, test_sample_count=len(rows))), flush=True)
    return report

"""Evaluate a selected checkpoint without model downloads or threshold tuning."""
import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from src.data.epc_data import EvidenceCollator, EvidenceDataset, load_bundle
from src.models.epc_ecn import EPCConfig, EPCECN
from src.train.train_epc_ecn import PAPER_COUNTS, evaluate, resolve


def load_checkpoint(path, device='cpu'):
    from transformers import AutoTokenizer, RobertaConfig, RobertaModel
    path = resolve(path)
    checkpoint = torch.load(path, map_location='cpu', weights_only=True)
    if checkpoint.get('schema_version') != 1:
        raise ValueError('Unsupported EPC checkpoint version')
    cfg = EPCConfig(**checkpoint['model_config'])
    encoder, tokenizer = None, None
    if cfg.use_explanation:
        encoder = RobertaModel(RobertaConfig.from_dict(checkpoint['roberta_config']))
        tokenizer = AutoTokenizer.from_pretrained(path.parent / 'tokenizer', local_files_only=True)
    model = EPCECN(cfg, encoder)
    model.load_state_dict(checkpoint['model_state_dict'], strict=True)
    return model.to(device).eval(), tokenizer, checkpoint


def run(args):
    device = torch.device(args.device)
    torch.set_num_threads(4)
    cache_path, checkpoint_path, output = resolve(args.cache), resolve(args.checkpoint), resolve(args.output)
    if output.exists():
        raise FileExistsError(f'Refusing to overwrite evaluation: {output}')
    print(f'Cache: {cache_path}\nCheckpoint: {checkpoint_path}\nOutput: {output}', flush=True)
    bundle = load_bundle(cache_path)
    model, tokenizer, checkpoint = load_checkpoint(checkpoint_path, device)
    training_meta = checkpoint['run']['cache_metadata']
    if training_meta['bundle_sha256'] != bundle['metadata']['bundle_sha256']:
        raise ValueError('Evaluation cache differs from the cache recorded during training')
    dataset = EvidenceDataset(bundle, args.split, tokenizer, checkpoint['explanation_max_length'],
                              require_labels=not args.predict_only)
    if not args.predict_only and checkpoint['run']['config']['data'].get('require_paper_counts', True):
        counts = {int(k): int(v) for k, v in zip(*np.unique(dataset.labels, return_counts=True))}
        expected = PAPER_COUNTS[bundle['metadata']['dataset']][args.split]
        if counts != expected:
            raise ValueError(f'{args.split} label counts {counts} differ from the paper: {expected}')
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, collate_fn=EvidenceCollator(tokenizer))
    scores, rows = evaluate(model, loader, device)
    output.mkdir(parents=True)
    frame = pd.DataFrame(rows)
    frame.to_csv(output / 'predictions.csv', index=False)
    report = dict(checkpoint=str(checkpoint_path.resolve()), split=args.split, threshold=0.5,
                  sample_count=len(frame), metrics=None if args.predict_only else scores,
                  seed=checkpoint['run']['seed'], best_epoch=checkpoint['epoch'],
                  cache_sha256=bundle['metadata']['bundle_sha256'])
    if {'confidence', 'gate_mean'}.issubset(frame.columns):
        groups = {}
        for name, mask in [('high', frame.confidence >= 0.80), ('low', frame.confidence < 0.80)]:
            subset = frame[mask]
            groups[name] = {'count': len(subset)}
            if len(subset):
                groups[name].update({col: float(subset[col].mean()) for col in ['confidence', 'gate_mean', 'normalized_entropy']})
                if not args.predict_only:
                    groups[name]['accuracy'] = float((subset.label == subset.prediction).mean())
        report['confidence_groups'] = groups
    if model.memory is not None:
        p = torch.nn.functional.normalize(model.memory.prototypes.detach(), dim=-1)
        similarity = (p @ p.T).abs().cpu().numpy()
        np.save(output / 'prototype_absolute_cosine.npy', similarity)
        off_diagonal = similarity[~np.eye(len(similarity), dtype=bool)]
        report['prototype_mean_absolute_cosine'] = float(off_diagonal.mean()) if off_diagonal.size else 0.0
    (output / 'metrics.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checkpoint', required=True)
    parser.add_argument('--cache', required=True)
    parser.add_argument('--split', choices=['val', 'test'], default='test')
    parser.add_argument('--output', required=True)
    parser.add_argument('--device', default='cuda' if torch.cuda.is_available() else 'cpu')
    parser.add_argument('--batch-size', type=int, default=32)
    parser.add_argument('--predict-only', action='store_true')
    run(parser.parse_args())


if __name__ == '__main__':
    main()

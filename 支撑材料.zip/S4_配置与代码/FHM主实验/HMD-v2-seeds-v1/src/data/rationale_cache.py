"""Auditable reuse/repair of explanation caches. No API or credential access."""
import copy
import hashlib
import json
from collections import Counter
from pathlib import Path
from urllib.parse import urlsplit

import numpy as np
import pandas as pd

from src.data.epc_data import canonical_id, load_bundle, read_csv, sha256


def valid_explanation(value):
    return isinstance(value, str) and bool(value.strip()) and not value.strip().lower().startswith('error')


def image_identity(value):
    return canonical_id(Path(str(value).replace('\\', '/')).stem)


def row_problem(row, expected):
    if row is None:
        return 'missing'
    if not valid_explanation(row.get('rationale')):
        return 'empty_or_error'
    if str(row.get('text', '')) != expected['text']:
        return 'text_mismatch'
    if 'img' in row and image_identity(row['img']) != image_identity(expected['img']):
        return 'image_mismatch'
    return None


def atomic_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    temporary.replace(path)


def normalize_endpoint(endpoint):
    endpoint = str(endpoint).strip().rstrip('/')
    parsed = urlsplit(endpoint)
    if (parsed.scheme not in {'https', 'http'} or not parsed.hostname
            or parsed.username is not None or parsed.password is not None
            or parsed.query or parsed.fragment):
        raise ValueError('API base URL must be an HTTP(S) URL without credentials, query or fragment')
    return endpoint


def generation_settings(manifest, prompt, endpoint='https://api.openai.com/v1'):
    return dict(model='gpt-4o', temperature=0.2, top_p=0.9, max_tokens=128,
                prompt_sha256=sha256(prompt), manifest_sha256=sha256(manifest),
                endpoint=normalize_endpoint(endpoint))


def text_sha256(value):
    return hashlib.sha256(str(value).encode('utf-8')).hexdigest()


def validate_manual_provenance(row, provenance):
    """Supplementation must identify its author and bind evidence to its text."""
    if not isinstance(provenance, dict):
        raise ValueError('Manual annotation lacks provenance')
    for field in ['authored_by', 'authorization', 'reason', 'created_utc']:
        if not isinstance(provenance.get(field), str) or not provenance[field].strip():
            raise ValueError(f'Manual annotation lacks {field}')
    if not isinstance(provenance.get('human_reviewed'), bool):
        raise ValueError('Manual annotation must declare human_reviewed explicitly')
    if (provenance.get('text_sha256') != text_sha256(row['text'])
            or provenance.get('rationale_sha256') != text_sha256(row['rationale'])):
        raise ValueError('Manual annotation text differs from its provenance')
    image_hash = provenance.get('image_sha256', '')
    if not isinstance(image_hash, str) or len(image_hash) != 64 or any(c not in '0123456789abcdef' for c in image_hash):
        raise ValueError('Manual annotation lacks an image hash')


def apply_manual_annotations(plan, annotation_path, image_root='.'):
    """Explicitly import user-authorized supplements, only into unresolved rows."""
    if plan['mode'] != 'repair':
        raise ValueError('Manual annotations are only allowed in repair mode')
    document = json.loads(Path(annotation_path).read_text(encoding='utf-8'))
    if (document.get('schema_version') != 1
            or document.get('manifest_sha256') != plan['settings']['manifest_sha256']):
        raise ValueError('Manual annotations do not match this manifest')
    annotations = document.get('annotations')
    if not isinstance(annotations, list) or not annotations:
        raise ValueError('Manual annotations must contain at least one record')
    expected = plan['manifest'].set_index('id').to_dict('index')
    additions = {}
    for entry in annotations:
        row = {key: entry[key] for key in ['id', 'img', 'text', 'rationale', 'rationale_source', 'manual_provenance']}
        row['id'] = canonical_id(row['id'])
        sample_id = row['id']
        if (sample_id not in expected or sample_id in additions
                or row['rationale_source'] != 'manual' or row_problem(row, expected[sample_id])):
            raise ValueError('Unknown, duplicate, mismatched or invalid manual annotation')
        validate_manual_provenance(row, row['manual_provenance'])
        image = Path(expected[sample_id]['img'])
        if not image.is_absolute():
            image = Path(image_root) / image
        if sha256(image) != row['manual_provenance']['image_sha256']:
            raise ValueError('Manual annotation image differs from reviewed evidence')
        existing = plan['records'].get(sample_id)
        if existing is not None and existing != row:
            raise ValueError('Manual annotations cannot overwrite an existing explanation')
        additions[sample_id] = row
    plan['records'].update(additions)


def plan_cache(manifest_path, legacy_path, output, prompt_path, mode='repair', legacy_encoding='gb18030',
               endpoint='https://api.openai.com/v1'):
    """Keep every valid legacy row. Import previously paid results only for gaps."""
    if mode not in {'repair', 'full'}:
        raise ValueError('Mode must be repair or full')
    output = Path(output)
    if output.suffix.lower() != '.csv':
        raise ValueError('Output must end in .csv. Put a SPACE before --execute in PyCharm Parameters.')
    if output.resolve() in {Path(manifest_path).resolve(), Path(legacy_path).resolve()}:
        raise ValueError('Output must not overwrite the manifest or legacy cache')
    manifest = read_csv(manifest_path)
    if not {'text', 'img'}.issubset(manifest.columns) or manifest.empty:
        raise ValueError('Manifest must contain nonempty id,img,text rows')
    manifest['text'] = manifest.text.fillna('').astype(str)
    expected = manifest.set_index('id').to_dict('index')
    settings = generation_settings(manifest_path, prompt_path, endpoint)
    source = None
    records, problems = {}, {}
    if mode == 'repair':
        legacy = read_csv(legacy_path, encoding=legacy_encoding).fillna('')
        if not {'text', 'rationale'}.issubset(legacy.columns):
            raise ValueError('Legacy cache needs text and rationale columns for identity checks')
        legacy_rows = legacy.set_index('id').to_dict('index')
        source = dict(path=str(Path(legacy_path).resolve()), sha256=sha256(legacy_path), encoding=legacy_encoding,
                      generation_settings='legacy prompt and parameters; not the current paper protocol')
        for sample_id, sample in expected.items():
            row = legacy_rows.get(sample_id)
            problem = row_problem(row, sample)
            if problem:
                problems[sample_id] = problem
            else:
                records[sample_id] = dict(id=sample_id, text=sample['text'], img=sample['img'],
                    rationale=row['rationale'], rationale_source='legacy')
    else:
        problems = {sample_id: 'full_generation_requested' for sample_id in expected}
    state_path = output.with_suffix('.state.json')
    expected_identity = dict(settings=settings, mode=mode, legacy_source=source)
    if state_path.exists():
        state = json.loads(state_path.read_text(encoding='utf-8'))
        if (state.get('schema_version') != 2 or state.get('mode') != mode
                or state.get('legacy_source') != source):
            raise ValueError('Repair state inputs/settings changed; use a new output filename')
        old_settings = state.get('settings', {})
        changed = {k for k in old_settings.keys() | settings.keys() if old_settings.get(k) != settings.get(k)}
        if changed:
            # A failed first request has no generated provenance to invalidate.
            # Never relabel already generated explanations as from another API.
            has_generated = any(row.get('rationale_source') == 'generated' for row in state['records'])
            if changed == {'endpoint'} and has_generated:
                raise ValueError('API endpoint changed after generated repairs were saved; keep the previous '
                                 'endpoint or use a new output filename. Existing results are preserved.')
            if changed != {'endpoint'} or has_generated:
                raise ValueError('Repair state inputs/settings changed; use a new output filename')
        seen = set()
        for row in state['records']:
            sample_id = row['id']
            if sample_id not in expected or sample_id in seen or row_problem(row, expected[sample_id]):
                raise ValueError('Repair state has duplicate, unknown, or invalid rows')
            seen.add(sample_id)
            if row['rationale_source'] == 'legacy':
                if sample_id not in records or row['rationale'] != records[sample_id]['rationale']:
                    raise ValueError('Legacy row changed in repair state')
            elif row['rationale_source'] == 'generated':
                if sample_id not in records:
                    records[sample_id] = row
            elif row['rationale_source'] == 'manual':
                if mode != 'repair' or sample_id in records:
                    raise ValueError('Manual annotation conflicts with mode or legacy explanation')
                validate_manual_provenance(row, row.get('manual_provenance'))
                records[sample_id] = row
            else:
                raise ValueError('Unknown rationale source in repair state')
    elif output.exists():
        # Import partial output from the earlier full-generation script without spending again.
        metadata_path = output.with_suffix('.json')
        if not metadata_path.exists():
            raise ValueError('Existing output lacks provenance; choose a new output filename')
        old = json.loads(metadata_path.read_text(encoding='utf-8'))
        if old.get('csv_sha256') != sha256(output) or any(old.get(k) != v for k, v in settings.items()):
            raise ValueError('Existing generated CSV/settings mismatch; refusing to reuse or overwrite it')
        if old.get('schema_version') == 2:
            raise ValueError('Version 2 output is missing its authoritative .state.json file')
        for row in read_csv(output).fillna('').to_dict('records'):
            sample_id = row['id']
            if sample_id not in expected or row_problem(row, expected[sample_id]):
                raise ValueError('Existing generated output has unknown or mismatched rows')
            if sample_id not in records:
                records[sample_id] = {**row, 'rationale_source': 'generated'}
    return dict(schema_version=2, **expected_identity, records=records, problems=problems,
                manifest=manifest, output=output)


def pending_rows(plan):
    return plan['manifest'][~plan['manifest'].id.isin(plan['records'])]


def plan_summary(plan):
    counts = Counter(r['rationale_source'] for r in plan['records'].values())
    return dict(mode=plan['mode'], total=len(plan['manifest']), reused_legacy=counts['legacy'],
                repaired_or_previously_generated=counts['generated'],
                manual_annotations=counts['manual'],
                problem_items=len(plan['problems']), remaining_api_requests=len(pending_rows(plan)))


def save_cache(plan):
    """Commit authoritative JSON first, then export recoverable CSV/metadata.

    A stop between writes is repaired from state on restart without repeating
    already committed API requests. No credentials are stored in any file.
    """
    output = plan['output']
    output.parent.mkdir(parents=True, exist_ok=True)
    records = [plan['records'][sample_id] for sample_id in plan['manifest'].id if sample_id in plan['records']]
    state = {k: plan[k] for k in ['schema_version', 'settings', 'mode', 'legacy_source']}
    state['records'] = records
    atomic_json(output.with_suffix('.state.json'), state)
    temporary = output.with_name(output.name + '.tmp')
    pd.DataFrame(records, columns=['id', 'text', 'img', 'rationale', 'rationale_source']).to_csv(
        temporary, index=False, encoding='utf-8-sig')
    temporary.replace(output)
    summary = plan_summary(plan)
    metadata = dict(schema_version=2, **plan['settings'], **summary, csv_sha256=sha256(output),
                    complete=summary['remaining_api_requests'] == 0, count=len(records),
                    legacy_source=plan['legacy_source'],
                    manual_provenance={r['id']: r['manual_provenance'] for r in records if r['rationale_source'] == 'manual'},
                    originally_invalid_ids=list(plan['problems']),
                    pending_ids=pending_rows(plan).id.tolist(),
                    explanation_protocol='legacy_cache_with_targeted_repairs' if plan['mode'] == 'repair' else 'paper_full')
    atomic_json(output.with_suffix('.json'), metadata)
    cols = ['id', 'split', 'img', 'text'] if 'split' in plan['manifest'] else ['id', 'img', 'text']
    pending = pending_rows(plan)[cols].copy()
    pending['reason'] = pending.id.map(plan['problems'])
    pending.to_csv(output.with_suffix('.pending.csv'), index=False, encoding='utf-8-sig')
    return metadata


def verified_protocol(frame, metadata, csv_path, prompt_path):
    """Mixed caches can pass repair policy, but never masquerade as paper-generated."""
    if metadata.get('csv_sha256') != sha256(csv_path):
        raise ValueError('Rationale CSV hash differs from its generation record')
    matching = (metadata.get('prompt_sha256') == sha256(prompt_path)
                and metadata.get('model') == 'gpt-4o' and metadata.get('temperature') == .2
                and metadata.get('top_p') == .9 and metadata.get('max_tokens') == 128)
    complete = metadata.get('complete') is True and metadata.get('count') == len(frame)
    if metadata.get('schema_version') == 2:
        if 'rationale_source' not in frame:
            raise ValueError('Repaired cache is missing per-row provenance')
        counts = frame.rationale_source.value_counts().to_dict()
        if not set(counts).issubset({'legacy', 'generated', 'manual'}):
            raise ValueError('Unrecognized rationale source')
        if counts.get('legacy', 0) != metadata.get('reused_legacy') or counts.get('generated', 0) != metadata.get('repaired_or_previously_generated'):
            raise ValueError('Per-row provenance counts differ from metadata')
        if counts.get('manual', 0) != metadata.get('manual_annotations', 0):
            raise ValueError('Manual provenance counts differ from metadata')
        manual_rows = frame[frame.rationale_source == 'manual'].to_dict('records')
        provenance = metadata.get('manual_provenance', {})
        if not isinstance(provenance, dict) or set(provenance) != {r['id'] for r in manual_rows}:
            raise ValueError('Manual provenance IDs differ from the CSV')
        for row in manual_rows:
            validate_manual_provenance(row, provenance[row['id']])
        repaired = bool(complete and matching and metadata.get('mode') == 'repair'
                        and metadata.get('remaining_api_requests') == 0 and metadata.get('legacy_source'))
        paper = bool(complete and matching and counts.get('legacy', 0) == 0 and counts.get('manual', 0) == 0)
    else:
        repaired, paper = False, bool(complete and matching)
    return paper, repaired


def build_repaired_bundle(plan, base_cache, output_cache, prompt_path):
    """Reuse audited CLIP/labels unchanged and substitute only explanation strings."""
    if plan['mode'] != 'repair':
        return None
    base_cache, output_cache = Path(base_cache), Path(output_cache)
    if base_cache.resolve() == output_cache.resolve():
        raise ValueError('Repaired bundle must not overwrite the original audited cache')
    base_manifest = base_cache.with_suffix('.manifest.csv')
    if not base_manifest.exists() or sha256(base_manifest) != plan['settings']['manifest_sha256']:
        raise ValueError('Repair manifest differs from the audited CLIP cache manifest')
    bundle = load_bundle(base_cache)
    if set(bundle['ids']) != set(plan['manifest'].id):
        raise ValueError('Repair manifest IDs differ from base cache')
    base_sha = sha256(base_cache)
    if output_cache.exists():
        previous_meta = output_cache.with_suffix('.json')
        if not previous_meta.exists() or json.loads(previous_meta.read_text(encoding='utf-8')).get('repair_base_sha256') != base_sha:
            raise ValueError('Refusing to overwrite an unrelated feature cache')
    generation = json.loads(plan['output'].with_suffix('.json').read_text(encoding='utf-8'))
    frame = read_csv(plan['output'])
    paper, repaired = verified_protocol(frame, generation, plan['output'], prompt_path)
    rationales = np.array([plan['records'].get(sample_id, {}).get('rationale', '') for sample_id in bundle['ids']], dtype=str)
    bad = [str(sample_id) for sample_id, value in zip(bundle['ids'], rationales) if not valid_explanation(value)]
    metadata = copy.deepcopy(bundle['metadata'])
    metadata.update(paper_explanations=paper and not bad, repaired_explanations=repaired and not bad,
        explanation_protocol='legacy_cache_with_targeted_repairs', invalid_rationales=len(bad),
        mismatched_rationale_texts=0, unusable_rationale_count=len(bad), unusable_rationale_ids=bad,
        missing_rationale_ids=bad, repair_base_sha256=base_sha)
    metadata['sources']['generation'] = generation
    metadata['sources']['rationales'] = dict(path=str(plan['output'].resolve()), sha256=sha256(plan['output']), encoding='utf-8-sig')
    output_cache.parent.mkdir(parents=True, exist_ok=True)
    temporary = output_cache.with_name(output_cache.name + '.tmp')
    with temporary.open('wb') as stream:
        np.savez_compressed(stream, **{k: bundle[k] for k in ['ids', 'splits', 'labels', 'image', 'text']}, rationales=rationales)
    temporary.replace(output_cache)
    metadata['bundle_sha256'] = sha256(output_cache)
    atomic_json(output_cache.with_suffix('.json'), metadata)
    result_manifest = plan['manifest'].set_index('id').loc[bundle['ids']].reset_index()
    result_manifest['rationale'] = rationales
    result_manifest['rationale_source'] = [plan['records'].get(s, {}).get('rationale_source', 'pending') for s in bundle['ids']]
    result_manifest.to_csv(output_cache.with_suffix('.manifest.csv'), index=False, encoding='utf-8-sig')
    return metadata

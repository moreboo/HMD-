"""Validated ID joins and frozen CLIP cache for EPC-ECN."""
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset


def canonical_id(value):
    value = str(value).strip()
    if value.endswith('.0') and value[:-2].isdigit():
        value = value[:-2]
    return str(int(value)) if value.isdigit() else value


def read_csv(path, encoding='utf-8-sig', **kwargs):
    df = pd.read_csv(path, encoding=encoding, dtype={'id': str}, **kwargs)
    if 'id' not in df or df.id.isna().any():
        raise ValueError(f'Missing IDs in {path}')
    df['id'] = df.id.map(canonical_id)
    if df.id.eq('').any() or df.id.duplicated().any():
        raise ValueError(f'Empty or duplicate IDs in {path}')
    return df


def sha256(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def load_bundle(path):
    path = Path(path)
    with np.load(path, allow_pickle=False) as data:
        required = {'ids', 'splits', 'labels', 'image', 'text', 'rationales'}
        if not required.issubset(data.files):
            raise ValueError(f'Cache missing {sorted(required - set(data.files))}')
        bundle = {key: data[key].copy() for key in required}
    n = len(bundle['ids'])
    if not n or any(len(value) != n for value in bundle.values()):
        raise ValueError('Empty cache or inconsistent row counts')
    if len(set(bundle['ids'].tolist())) != n:
        raise ValueError('Duplicate IDs across dataset splits')
    if not set(bundle['splits']).issubset({'train', 'val', 'test'}):
        raise ValueError('Only exact train/val/test split names are allowed')
    if not np.isin(bundle['labels'], [-1, 0, 1]).all():
        raise ValueError('Labels must be -1 (unlabelled), 0 or 1')
    for key in ('image', 'text'):
        values = bundle[key]
        if values.ndim != 2 or not np.isfinite(values).all():
            raise ValueError(f'Invalid {key} features')
        if not np.allclose(np.linalg.norm(values, axis=1), 1, atol=2e-3):
            raise ValueError(f'{key} CLIP embeddings must be L2 normalized')
    if bundle['image'].shape != bundle['text'].shape:
        raise ValueError('CLIP image/text dimensions do not match')
    meta = path.with_suffix('.json')
    if not meta.exists():
        raise ValueError(f'Missing cache provenance: {meta}')
    bundle['metadata'] = json.loads(meta.read_text(encoding='utf-8'))
    if bundle['metadata'].get('bundle_sha256') != sha256(path):
        raise ValueError('Cache hash differs from provenance; prepare the cache again')
    return bundle


class EvidenceDataset(Dataset):
    def __init__(self, bundle, split, tokenizer=None, max_length=128, require_labels=True):
        self.indices = np.flatnonzero(bundle['splits'] == split)
        if not len(self.indices):
            raise ValueError(f'No samples in split {split}')
        self.labels = bundle['labels'][self.indices]
        if require_labels and not np.isin(self.labels, [0, 1]).all():
            raise ValueError(f'{split} contains unverified/missing labels; supply an explicit label source')
        self.image = torch.from_numpy(bundle['image'][self.indices].astype(np.float32))
        self.text = torch.from_numpy(bundle['text'][self.indices].astype(np.float32))
        self.ids = bundle['ids'][self.indices]
        self.tokens = None
        if tokenizer is not None:
            rationales = bundle['rationales'][self.indices].tolist()
            bad = [str(self.ids[i]) for i, value in enumerate(rationales)
                   if not value.strip() or value.strip().lower().startswith(('error', 'error_api'))]
            if bad:
                raise ValueError(f'{split}: {len(bad)} missing/invalid explanations; repair the cache. IDs: {bad[:10]}')
            self.tokens = tokenizer(rationales, truncation=True, max_length=max_length, padding=False)

    def __len__(self):
        return len(self.indices)

    def __getitem__(self, index):
        row = dict(image=self.image[index], text=self.text[index], label=int(self.labels[index]), id=str(self.ids[index]))
        if self.tokens is not None:
            row['input_ids'] = self.tokens['input_ids'][index]
            row['attention_mask'] = self.tokens['attention_mask'][index]
        return row


class EvidenceCollator:
    def __init__(self, tokenizer=None):
        self.tokenizer = tokenizer

    def __call__(self, rows):
        result = dict(image=torch.stack([r['image'] for r in rows]),
                      text=torch.stack([r['text'] for r in rows]),
                      labels=torch.tensor([r['label'] for r in rows], dtype=torch.long),
                      ids=[r['id'] for r in rows])
        if self.tokenizer is not None:
            tokens = self.tokenizer.pad([{'input_ids': r['input_ids'], 'attention_mask': r['attention_mask']}
                                         for r in rows], padding=True, return_tensors='pt')
            result.update(input_ids=tokens['input_ids'], attention_mask=tokens['attention_mask'])
        return result

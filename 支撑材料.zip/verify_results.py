"""Recompute submitted prediction metrics using only Python's standard library.
Usage: python verify_results.py [support_data_directory]
No training, model download, API call, or source archive code execution.
"""
from pathlib import Path
import csv, json, sys, statistics
from collections import defaultdict
root=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent
def read(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def auc(y,p):
    a=sorted(zip(p,y));s=0.;i=0
    while i<len(a):
        j=i+1
        while j<len(a) and a[j][0]==a[i][0]:j+=1
        s+=sum(v for _,v in a[i:j])*(i+1+j)/2;i=j
    n1=sum(y);return (s-n1*(n1+1)/2)/(n1*(len(y)-n1))
records=read(root/'S3_复算结果/逐次运行指标.csv')
groups=defaultdict(list);trans=[];dataset_labels={}
for r in records:
    ps=read(root/r['predictions']); y=[int(v['label']) for v in ps];p=[float(v['probability']) for v in ps]
    assert len(ps)==int(r['n']) and len(set(v['id'] for v in ps))==len(ps)
    lm={v['id']:int(v['label']) for v in ps}
    if r['dataset'] in dataset_labels:assert lm==dataset_labels[r['dataset']]
    else:dataset_labels[r['dataset']]=lm
    assert all(0<=v<=1 for v in p)
    assert all(int(v['prediction'])==int(float(v['probability'])>=.5) for v in ps)
    acc=sum(int((v>=.5)==t) for v,t in zip(p,y))/len(y)*100;au=auc(y,p)*100
    assert abs(acc-float(r['accuracy_percent']))<1e-9
    assert abs(au-float(r['auroc_percent']))<1e-9
    groups[(r['dataset'],r['group'],r['model'])].append((acc,au))
    if r['dataset']=='FHM' and r['model']=='main':
        for bc,fc in [(1,1),(1,0),(0,1),(0,0)]:
            count=sum((int((float(v['base_probability'])>=.5)==int(v['label']))==bc) and (int((float(v['probability'])>=.5)==int(v['label']))==fc) for v in ps)
            trans.append((int(r['seed']),bc,fc,count))
for r in read(root/'S3_复算结果/按实际运行次数汇总.csv'):
    vals=groups[(r['dataset'],r['group'],r['model'])]
    assert len(vals)==int(r['runs'])
    for j,key in enumerate(['accuracy','auroc']):
        x=[v[j] for v in vals]
        assert abs(statistics.mean(x)-float(r[key+'_mean']))<1e-9
        if len(x)>1:assert abs(statistics.stdev(x)-float(r[key+'_sample_sd']))<1e-9
        else:assert r[key+'_sample_sd']==''
for r in read(root/'S3_复算结果/预测正确性转移逐种子.csv'):
    assert (int(r['seed']),int(r['base_correct']),int(r['fused_correct']),int(r['count'])) in trans
print(json.dumps({'status':'PASS','prediction_metric_records':len(records),'transition_records':len(trans),'note':'Metric rows can share a checkpoint across analyses; this count is not a count of independent training runs.'},ensure_ascii=False,indent=2))
